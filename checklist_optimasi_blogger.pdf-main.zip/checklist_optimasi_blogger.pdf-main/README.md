# checklist_optimasi_blogger.pdf
langkah-langkah praktis optimasi Blogger supaya skor Performa dan SEO bisa di atas 90. 
